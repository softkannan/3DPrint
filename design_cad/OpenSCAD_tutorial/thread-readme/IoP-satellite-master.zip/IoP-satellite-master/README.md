# IoP-satellite
A collection of bits and pieces related to the Internet of Plants
