// Bottle generator version 2 by Geoff G
// For use with 38mm milk bottle caps
// From https://www.printables.com/model/368455
// License CC-BY-NC-SA 4.0  -  http://creativecommons.org/licenses/by-nc-sa/4.0/
// Requires UB.scad - from https://github.com/UBaer21/UB.scad

include<ub.scad>;

bottle(); // Customise bottle parameters here

module bottle(
// Available parameters and their default values
oh=50,      // Overall height
bd=40,      // Bottle diameter (Does not apply to thread)
uth=3,      // Upper taper height
lth=3,      // Lower taper height
ltf=1,       // Lower taper factor (sensibly between 1=45deg. to 0=none/straight.)
wt=1.2,     // Wall thickness (Add 2x to desired internal diameter)
bt=1.6,     // Base thickness  (Add to desired internal height) 
ar=180,     // Angular resolution (no. of sides on circumference)
nh=10,      // * Neck height (determines length of turns)
nex=0,     // Neck extension (extra unthreaded height)
nd=34.5,      // * Neck diameter
tw=3,      // * Thread width
// * --  Some variables that alter bottle top compatibilty

){
    union()     {
        T(0,0,oh-nh)Gewinde(  // Thread module
  p=4,        // Pitch per revolution
  dn=nd+tw,       // Diameter nominal
  kern=nd, //  Core diameter (⇐ dn)
  breite=.8, // thickness of end rounding
  rad1=1.3,  // rounding radius 1 (⇐ p g rund breite)
  rad2=.6,  //  rounding radius 2 (⇐ p g rund breite)
  //winkel=60,  // inclusive thread angle e.g 29 for ACME or 55 for BSW can be list [10,40] for buttress
  wand=wt,     // wall thickness (⇐ mantel)
  //mantel=33, // inner or outer shell diameter (↦ wand)
  h=nh, // height (↦ grad)
  //gb=2, // thread path height (⇐ p)
  //innen=false, // inner or outer thread
  //grad=480,   // degrees (⇐ h)
  start=12,    // fragments for primed start
  end=12,     // fragments for primed End
  korrektur=true, // correction of profil angle according to pitch
  profil=false,  // show profile polygon used
  //fn2=24, // profile roundingfragments
  fn=ar,//  thread fragments per revolution
  cyl=true, // add cylinder (h,d=Kern);
  tz=0,     //  move thread z
  //konisch=0, // tapered thread angle
  center=0,  // center thread
  //rund=false, // round thread (↦ rad1 rad2)
  //ratio=undef,// ratio between threads and space (↦ breite)
  //spiel=0.15, // clearance only for presets inner threads
  //name=undef, // name for info
  help=false  // help
);
            T(0,0,oh-nh-nex)difference(){   // Neck extension
                cylinder(h=nex,r=nd/2,$fn=ar);
                cylinder(h=nex,r=nd/2-wt,$fn=ar);
            }
            T(0,0,oh-nh-nex-uth)difference(){   // Upper taper
                cylinder(h=uth,r1=bd/2,r2=nd/2,$fn=ar);
                cylinder(h=uth,r1=bd/2-wt,r2=(nd/2)-wt,$fn=ar);
            }
            T(0,0,lth)difference(){   // Main cylinder
                cylinder(h=oh-nh-nex-uth-lth,r=bd/2,$fn=ar);
                cylinder(h=oh-nh-nex-uth-lth,r=(bd/2)-wt,$fn=ar);
            }
            difference(){   // Lower taper and base
                cylinder(h=lth,r1=bd/2-(lth*ltf),r2=bd/2,$fn=ar);
                cylinder(h=lth,r1=(bd/2)-lth*ltf-wt,r2=(bd/2)-wt,$fn=ar);
                }
                cylinder(h=bt,r1=bd/2-(lth*ltf),r2=bd/2-(lth*ltf)+((bd/2-(bd/2-(lth*ltf)))/(lth/bt)),$fn=ar);
                }
}

// CHANGE LOG
// v1   First published version
// v2   Added parameter "nex"