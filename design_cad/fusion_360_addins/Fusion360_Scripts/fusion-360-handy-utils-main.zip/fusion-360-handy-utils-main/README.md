# fusion-360-handy-utils

> A Fusion360 plugin providing a bunch of handy functions top model 3D Printable designs


# Solid / Modify

* **Cut Fastener Hole**: For a given starting sketch point and ending face, cuts a hole for a metric fastener screw for various head shapes (Socket, Counter Sunk, etc...) and anchors (Hex Nut, Heat Set Insert, etc ...)