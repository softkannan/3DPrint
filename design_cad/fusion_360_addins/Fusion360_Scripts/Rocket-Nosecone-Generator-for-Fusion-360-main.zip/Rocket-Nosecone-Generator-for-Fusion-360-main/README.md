# Rocket-Nosecone-Generator-for-Fusion-360
A Fusion 360 script to generator rocket nosecones

Put these two folders in: C:\Users\[username]\AppData\Roaming\Autodesk\Autodesk Fusion 360\API\Scripts or wherever this folder may be located.

Included is a script to install numpy as I needed to run that once for it to work.
