# AutoDesk Fusion360 Scripts
These are some python scripts to do random stuff in AutoDesk Fusion360. I'm both a 
Python n00b and a Fusion360 n00b, so I make no promises about any of this stuff.

To use this stuff, I just make the 'Scripts' directory in the Roaming profile of my PC
a junction to this GitHub repo, instead.

The Bill-Of-Materials thing is actually kind of handy for woodworking designs. Everything
else was written to solve a particular problem I was hitting, and I don't necessarily
even recall what problem it was... Sorry!
