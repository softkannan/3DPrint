# Threadzilla
Plug-in for Fusion 360, enabling users to easily create custom thread profiles.

# Privacy Policy
This plug-in does not collect any data, work with any third parties or retain any information.
