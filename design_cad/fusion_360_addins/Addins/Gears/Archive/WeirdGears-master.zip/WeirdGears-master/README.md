# WeirdGears
Fusion 360 python Add in to make non circular planet gears

The Fusion 360 sample code "spur gear" was used as a template to get going with the input commands and tool icon.
