# fusion_worm_gear
Script for generating worm gear in Fusion 360 environment.

# CHANGELOG

16.02.2020:
    1. Worm axis may be angled now
    2. Code refactored into more functions
    3. Improved documentation sketch