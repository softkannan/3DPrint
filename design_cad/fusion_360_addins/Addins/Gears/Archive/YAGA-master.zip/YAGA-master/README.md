
# Sketch Debugging

- To find missing constrains run `Sketch.ShowUnderConstrained` in the console (Alt + Ctrl + C).

# PyCharm

See https://github.com/JesusFreke/fusionIdea
