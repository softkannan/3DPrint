# 3D Parametric Gears

## [Parametric GT2 Pulley](parametric-gt2-pulley) (04/2020)

<table>
<tr>
<td><a href="parametric-gt2-pulley/"><img src="parametric-gt2-pulley/images/rendering1.thumb.png" alt="Rendering 1"/></a></td>
<td><a href="parametric-gt2-pulley/"><img src="parametric-gt2-pulley/images/rendering2.thumb.png" alt="Rendering 2"/></a></td>
</tr>
</table>

## [Bevel Gear Test](bevel-gear-test/) (12/2018)

<table>
<tr>
<td><a href="bevel-gear-test/"><img src="bevel-gear-test/images/rendering1.thumb.png" alt="Rendering 1"/></a></td>
<td><a href="bevel-gear-test/"><img src="bevel-gear-test/images/rendering2.thumb.png" alt="Rendering 2"/></a></td>
</tr>
</table>

## [Parametric Bevel Gear](parametric-bevel-gear/) (12/2018)

<table>
<tr>
<td><a href="parametric-bevel-gear/"><img src="parametric-bevel-gear/images/rendering1.thumb.png" alt="Rendering 1"/></a></td>
<td><a href="parametric-bevel-gear/"><img src="parametric-bevel-gear/images/involute-curve.thumb.png" alt="Involute Curve"/></a></td>
</tr>
</table>

## [Parametric Spur Gear](parametric-spur-gear/) (12/2018)

<table>
<tr>
<td><a href="parametric-spur-gear/"><img src="parametric-spur-gear/images/rendering1.thumb.png" alt="Rendering 1"/></a></td>
<td><a href="parametric-spur-gear/"><img src="parametric-spur-gear/images/involute-curve.thumb.png" alt="Involute Curve"/></a></td>
</tr>
</table>
