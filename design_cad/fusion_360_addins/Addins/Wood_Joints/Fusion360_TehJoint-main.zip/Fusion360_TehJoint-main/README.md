# Fusion360 TehJoint
Fusion360 Add-in for creating and jointing fasteners

![image](resources/Icon.png)

## Video 
* https://youtu.be/Z3jFxmKNM1Q
