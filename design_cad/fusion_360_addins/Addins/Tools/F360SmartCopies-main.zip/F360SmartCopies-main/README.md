# F360SmartCopies
Github project for the Fusion360 addin for automatic parameterization and copying of files.
