# **画面向きの平面**

本コマンドは、コマンド実行時の向きに平面を作成します。

---

## **使用法** :

「構築」パネルの平面の中にコマンドが追加されます。

![Alt text](./resources_readme/menu.png)

クリックする事でダイアログが表示されます。

![Alt text](./resources_readme/dialog.png)
+ 平面位置：何でも構わないので、対象となる要素をを選択します。


プレビューされます。良ければOKを押してください。

![Alt text](./resources_readme/exec.png)

---

## **注意** :

- 特になし

---

## **アクション** :

以下の環境で確認しています。

- Fusion360 Ver2.0.13866
- Windows10 64bit Pro , Home

---

## **ライセンス** :

- MIT

---

## 謝辞 :

- [日本語フォーラム](https://forums.autodesk.com/t5/fusion-360-ri-ben-yu/bd-p/707)の皆さん、ありがとう。