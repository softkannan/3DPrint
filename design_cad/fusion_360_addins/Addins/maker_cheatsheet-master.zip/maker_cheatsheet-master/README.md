# maker_cheatsheet
Cheat sheet used to make things

## Table of content
1. [Mechanical](./mechanical/README.md)
1. [3D Printing](./3d_printing/README.md)
1. [CAD Design](./cad_design/README.md)
