# example settings to be loaded
print('loading settings from ', __file__)

TEST_SETTING = 40 + 2
TEST_LIST = [ 2*i for i in range(3)]



