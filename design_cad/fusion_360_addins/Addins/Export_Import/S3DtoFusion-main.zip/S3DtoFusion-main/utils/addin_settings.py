# simple settings file that is available from everywhere
is_Experimental_active = False
