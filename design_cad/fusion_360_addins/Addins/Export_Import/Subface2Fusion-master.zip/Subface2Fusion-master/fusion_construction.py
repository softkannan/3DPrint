__author__ = "Jiri Manak <jiri.manak@aberamax.com>"
__license__ = 'GNU Affero General Public License http://www.gnu.org/licenses/agpl.html'
__copyright__ = "Copyright (C) 2020 Subface2Fusion Released under terms of the AGPLv3 License"

class OffsetConstructionPlane:

    def __init__(self):
        self.c_plane = None
        self.base_plane = None
        self.offset = 0

    def create_offset_plane(self, base_plane, offset):

        pass