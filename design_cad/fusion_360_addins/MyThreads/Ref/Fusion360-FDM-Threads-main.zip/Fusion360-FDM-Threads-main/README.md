# Fusion360-FDM-Threads
FDM compatible threads usable with fusion360

Place in `%localappdata%\Autodesk\webdeploy\Production\<current version ID>\Fusion\Server\Fusion\Configuration\ThreadData`

Most likely when Fusion360 updates it will not move the files so you will have to manually.
