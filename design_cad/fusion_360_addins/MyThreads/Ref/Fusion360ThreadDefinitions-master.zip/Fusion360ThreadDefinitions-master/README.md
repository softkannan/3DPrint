# Fusion360ThreadDefinitions
Custom Thread Definition Files for Fusion 360

Here I store all different custom thread definitions for Fusion 360 as I create them. 

If you want to know more about how these are installed and/or created, visit https://knowledge.autodesk.com/support/fusion-360/troubleshooting/caas/sfdcarticles/sfdcarticles/Custom-Threads-in-Fusion-360.html
