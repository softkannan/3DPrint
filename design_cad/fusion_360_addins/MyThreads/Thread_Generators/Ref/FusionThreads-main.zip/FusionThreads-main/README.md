# FusionThreads
Tool and data to create custom threads for Fusion 360

The spreadsheet contains a macro that will generate an XML file from the data in the active sheet. 

See https://knowledge.autodesk.com/support/fusion-360/learn-explore/caas/sfdcarticles/sfdcarticles/Custom-Threads-in-Fusion-360.html for info on where to put the file
