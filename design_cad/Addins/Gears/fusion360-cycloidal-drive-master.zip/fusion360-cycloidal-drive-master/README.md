# fusion360-cycloidal-drive
Parametric cycloidal drive generator script for Fusion 360

Based on [this script](https://github.com/mawildoer/cycloidal_generator)