# We need to keep track of our handlers so that they don't get cleaned up.
handlers = []
