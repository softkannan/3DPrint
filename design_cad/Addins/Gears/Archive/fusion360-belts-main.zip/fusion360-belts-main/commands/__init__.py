"""Timing Belt Generator - Generic Fusion 360 addin leveraging apper as a submodule"""

__version__ = '0.1.0'
__author__ = 'Ryan Wolfe <ryan.wolfe@gmail.com>'
__all__ = []