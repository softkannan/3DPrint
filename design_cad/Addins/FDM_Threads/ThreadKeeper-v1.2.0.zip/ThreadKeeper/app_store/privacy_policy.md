# Privacy Policy

This add-in does not collect any data or share any data with third parties.

E-mails sent to me, the developer, will be retained in my inbox, if nothing else is stated by the sender.

