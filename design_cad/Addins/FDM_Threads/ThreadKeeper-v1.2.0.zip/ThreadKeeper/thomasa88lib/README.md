# thomasa88lib

Autodesk® Fusion 360™ library for Python add-ins.

I add functions to the library as I need them, to create my [add-ins](https://github.com/topics/fusion-360?q=user%3Athomasa88&unscoped_q=user%3Athomasa88). Every Python file has a short description at the top.

Use thomasa88lib as a submodule in the add-in repository.

## Author

This add-in is created by Thomas Axelsson.

## License

This project is licensed under the terms of the MIT license. See [LICENSE](LICENSE).
