
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.17.4'
version = '1.17.4'
full_version = '1.17.4'
git_revision = '346f5b61e5a0da82f46760a66101589e7b776426'
release = True

if not release:
    version = full_version
