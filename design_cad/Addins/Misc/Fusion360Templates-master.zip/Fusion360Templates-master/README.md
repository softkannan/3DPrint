# About

This is a collection of "templates" for creating Scripts & Add-Ins for Autodesk Fusion360.
It allows you to get to the important bits faster, by, for example, setting up some of the common EventHandlers for creating a command.

# How to use

Select the file that best fits your purpose and copy the content into your Script/AddIn.
Look at the \#TODO: tags to know what you need to add. 