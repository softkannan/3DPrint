# Sample for non Feature-Based modelling in Fusion360

Here are a few examples of how to create Bodys, Surfaces and Construction geometry numerically without the use of features.

This significantly speeds up geometry creation and allows for otherwise impossible things.

## Notes

- The position for Spheres and Toroids does not seem to work correctly at this moment
