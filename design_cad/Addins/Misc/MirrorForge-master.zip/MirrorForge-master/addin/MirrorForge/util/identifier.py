MIRRORFORGE_PANEL_ID                = "mirrorforgePanelId"
COMMAND_ID_ADD_CURVE                = "mirrorforgeCommandAddCurve"
COMMAND_ID_EXPORT                   = "mirrorforgeCommandExport"

WIDGET_ID_ALLBODIES                 = "mirrorforgeWidgetAllBodies"
WIDGET_ID_MIRRORS                   = "mirrorforgeWidgetMirrors"

WIDGET_ID_CAMERA_ORIGIN             = "mirrorforgeWidgetCameraOrigin"
WIDGET_ID_CAMERA_DIRECTION          = "mirrorforgeWidgetCameraDirection"
WIDGET_ID_CAMERA_FOV                = "mirrorforgeWidgetCameraFov"

WIDGET_ID_PROJECTOR_ORIGIN          = "mirrorforgeWidgetProjectorOrigin"
WIDGET_ID_PROJECTOR_DIRECTION       = "mirrorforgeWidgetProjectorDirection"
WIDGET_ID_PROJECTOR_FOV             = "mirrorforgeWidgetProjectorFov"
WIDGET_ID_PROJECTOR_IMAGE           = "mirrorforgeWidgetProjectorImage"

# WIDGET_ID_CAMERA_ENABLE             = "mirrorforgeWidgetCameraEnable"