import logging

class Configuration:    

    LOG_FILE    = "/tmp/mirrorforge.log"
    LOG_LEVEL   = logging.DEBUG
    LOG_LEVEL   = logging.NOTSET