# fusion360utilities
a set of utilities for fusion 360

select an edge and a face
