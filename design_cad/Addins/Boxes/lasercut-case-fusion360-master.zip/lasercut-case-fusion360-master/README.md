# lasercut-case-fusion360
Fusion360 script to create lasercut cases.
