//
// Created by Hobbyist Maker on 9/2/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#define CONFIG_CATCH_MAIN
#include <catch.hpp>

