//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_UPDATEJOINTPLANES_HPP
#define SILVANUSPRO_UPDATEJOINTPLANES_HPP

#include <entt/entt.hpp>

void updateJointPlanesImpl(entt::registry& registry);

#endif //SILVANUSPRO_UPDATEJOINTPLANES_HPP
