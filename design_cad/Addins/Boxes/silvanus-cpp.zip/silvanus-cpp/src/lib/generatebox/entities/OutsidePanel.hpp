//
// Created by Hobbyist Maker on 8/2/20.
//

#ifndef SILVANUSPRO_OUTSIDEPANEL_HPP
#define SILVANUSPRO_OUTSIDEPANEL_HPP

namespace silvanus::generatebox::entities {
    struct OutsidePanel {
        bool value;
    };
}

#endif //SILVANUSPRO_OUTSIDEPANEL_HPP
