//
// Created by Hobbyist Maker on 8/7/20.
//

#ifndef SILVANUSPRO_INSIDEPANEL_HPP
#define SILVANUSPRO_INSIDEPANEL_HPP

namespace silvanus::generatebox::entities {
    struct InsidePanel {
        bool value = true;
    };
}

#endif //SILVANUSPRO_INSIDEPANEL_HPP
