//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_UPDATEPANELDIMENSIONS_HPP
#define SILVANUSPRO_UPDATEPANELDIMENSIONS_HPP

#include <entt/entt.hpp>

void updatePanelDimensionsImpl(entt::registry& registry);

#endif //SILVANUSPRO_UPDATEPANELDIMENSIONS_HPP
