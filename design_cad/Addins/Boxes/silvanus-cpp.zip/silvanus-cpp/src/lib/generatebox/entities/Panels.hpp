//
// Created by Hobbyist Maker on 8/14/20.
//

#ifndef SILVANUSPRO_PANELS_HPP
#define SILVANUSPRO_PANELS_HPP

namespace silvanus::generatebox::entities {

    enum class Panels {
            Top, Bottom, Left, Right, Front, Back, Length, Width, Height
    };
}

#endif //SILVANUSPRO_PANELS_HPP
