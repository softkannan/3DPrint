//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_UPDATEJOINTCOLLISIONDATA_HPP
#define SILVANUSPRO_UPDATEJOINTCOLLISIONDATA_HPP

#include <entt/entt.hpp>

void updateJointCollisionDataImpl(entt::registry& registry);

#endif //SILVANUSPRO_UPDATEJOINTCOLLISIONDATA_HPP
