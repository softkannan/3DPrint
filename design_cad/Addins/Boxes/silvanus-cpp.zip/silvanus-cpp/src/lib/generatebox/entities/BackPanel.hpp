//
// Created by Hobbyist Maker on 8/19/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_BACKPANEL_HPP
#define SILVANUSPRO_BACKPANEL_HPP

#include "entities/PanelTag.hpp"

namespace silvanus::generatebox::entities {

    struct BackPanel : public PanelTag {};
}

#endif //SILVANUSPRO_BACKPANEL_HPP
