//
// Created by Hobbyist Maker on 8/10/20.
//

#ifndef SILVANUSPRO_PANELTYPE_HPP
#define SILVANUSPRO_PANELTYPE_HPP

namespace silvanus::generatebox::entities {

    enum class PanelType {
            Outside, Inside
    };

}
#endif //SILVANUSPRO_PANELTYPE_HPP
