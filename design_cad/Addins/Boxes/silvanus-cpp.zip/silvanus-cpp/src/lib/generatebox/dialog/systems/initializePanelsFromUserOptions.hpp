//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_INITIALIZEPANELSFROMUSEROPTIONS_HPP
#define SILVANUSPRO_INITIALIZEPANELSFROMUSEROPTIONS_HPP

#include <entt/entt.hpp>

void initializePanelsFromUserOptionsImpl(entt::registry& configuration, entt::registry& registry);

#endif //SILVANUSPRO_INITIALIZEPANELSFROMUSEROPTIONS_HPP
