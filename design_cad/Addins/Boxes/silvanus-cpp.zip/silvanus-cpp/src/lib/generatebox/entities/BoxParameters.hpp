//
// Created by Hobbyist Maker on 9/10/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_BOXPARAMETERS_HPP
#define SILVANUSPRO_BOXPARAMETERS_HPP

#endif //SILVANUSPRO_BOXPARAMETERS_HPP
