//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_UPDATEENABLEVALUE_HPP
#define SILVANUSPRO_UPDATEENABLEVALUE_HPP

#include <entt/entt.hpp>

void updateEnableValueImpl(entt::registry& registry);

#endif //SILVANUSPRO_UPDATEENABLEVALUE_HPP
