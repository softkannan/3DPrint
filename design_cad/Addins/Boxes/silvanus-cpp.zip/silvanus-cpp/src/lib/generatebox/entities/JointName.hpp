//
// Created by Hobbyist Maker on 8/2/20.
//

#ifndef SILVANUSPRO_JOINTNAME_HPP
#define SILVANUSPRO_JOINTNAME_HPP

#include <string>

namespace silvanus::generatebox::entities {
    struct JointName {
        std::string value;
    };
}

#endif //SILVANUSPRO_JOINTNAME_HPP
