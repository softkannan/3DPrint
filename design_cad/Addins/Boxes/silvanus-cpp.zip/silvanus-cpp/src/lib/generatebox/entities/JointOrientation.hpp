//
// Created by Hobbyist Maker on 8/2/20.
//

#ifndef SILVANUSPRO_JOINTORIENTATION_HPP
#define SILVANUSPRO_JOINTORIENTATION_HPP

#include "AxisFlag.hpp"

namespace silvanus::generatebox::entities {
    struct JointOrientation {
        AxisFlag axis;
    };
}

#endif //SILVANUSPRO_JOINTORIENTATION_HPP
