//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_UPDATEFINGERPATTERN_HPP
#define SILVANUSPRO_UPDATEFINGERPATTERN_HPP

#include <entt/entt.hpp>

void updateFingerPatternTypeImpl(entt::registry& registry);

#endif //SILVANUSPRO_UPDATEFINGERPATTERN_HPP
