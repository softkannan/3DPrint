//
// Created by Hobbyist Maker on 8/2/20.
//

#ifndef SILVANUSPRO_PANELORIENTATION_HPP
#define SILVANUSPRO_PANELORIENTATION_HPP

#include "AxisFlag.hpp"

namespace silvanus::generatebox::entities {
    struct PanelOrientation
    {
        AxisFlag axis;
    };
}

#endif //SILVANUSPRO_PANELORIENTATION_HPP
