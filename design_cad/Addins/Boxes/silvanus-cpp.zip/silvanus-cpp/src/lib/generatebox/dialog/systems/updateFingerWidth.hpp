//
// Created by Hobbyist Maker on 9/15/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_UPDATEFINGERWIDTH_HPP
#define SILVANUSPRO_UPDATEFINGERWIDTH_HPP

#include <entt/entt.hpp>

void updateFingerWidthImpl(entt::registry &registry);

#endif //SILVANUSPRO_UPDATEFINGERWIDTH_HPP
