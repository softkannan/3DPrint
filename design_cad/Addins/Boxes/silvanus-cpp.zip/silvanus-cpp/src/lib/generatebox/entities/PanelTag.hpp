//
// Created by Hobbyist Maker on 8/19/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_PANELTAG_HPP
#define SILVANUSPRO_PANELTAG_HPP

namespace silvanus::generatebox::entities {

    struct PanelTag {
        bool value = true;
    };

}

#endif //SILVANUSPRO_PANELTAG_HPP
