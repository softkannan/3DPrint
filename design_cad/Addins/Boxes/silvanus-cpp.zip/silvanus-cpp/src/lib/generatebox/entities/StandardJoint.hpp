//
// Created by Hobbyist Maker on 9/5/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_STANDARDJOINT_HPP
#define SILVANUSPRO_STANDARDJOINT_HPP

namespace silvanus::generatebox::entities {

    struct StandardJoint {
        bool value = true;
    };
}
#endif //SILVANUSPRO_STANDARDJOINT_HPP
