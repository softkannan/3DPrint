//
// Created by Hobbyist Maker on 8/15/20.
//

#ifndef SILVANUSPRO_PANELID_HPP
#define SILVANUSPRO_PANELID_HPP

#include "entities/Panels.hpp"

namespace silvanus::generatebox::entities {

    struct PanelId {
        Panels value;
    };
}

#endif //SILVANUSPRO_PANELID_HPP
