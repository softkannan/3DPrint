//
// SilvanusPro
//
// Created by Hobbyist Maker on 7/26/20.
// Copyright (c) 2020 Hobbyist Maker. All rights reserved.
//

#ifndef SILVANUSPRO_SILVANUSPRO_H
#define SILVANUSPRO_SILVANUSPRO_H

#define SilvanusPro_VERSION_MAJOR 0
#define SilvanusPro_VERSION_MINOR 7


#endif /* silvanuspro_silvanuspro_h */
