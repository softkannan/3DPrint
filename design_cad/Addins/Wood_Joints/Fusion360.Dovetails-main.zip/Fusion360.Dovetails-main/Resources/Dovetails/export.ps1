magick -background none icon.svg -scale 16x16 -antialias 16x16.png
magick -background none icon.svg -scale 32x32 32x32.png
magick -background none icon.svg -scale 64x64 64x64.png
magick -background none icon.svg -set colorspace Gray -scale 16x16 16x16-disabled.png
magick -background none icon.svg -set colorspace Gray -scale 32x32 32x32-disabled.png
magick -background none icon.svg -set colorspace Gray -scale 64x64 64x64-disabled.png