# Change of Fusion360_SketchToolPlus

## 0.0.5
+ "Sketch Analysis" 要素のフォーカス機能追加

## 0.0.4
+ "起動時に実行"の不具合修正

## 0.0.3
+ "Sketch Analysis" 表示の不具合修正

## 0.0.2
+ 拘束不足の要素を強調表示する "Sketch Analysis" コマンド追加

## 0.0.1
+ ディバイダ コマンド追加
+ 2点間の線上距離 コマンド追加