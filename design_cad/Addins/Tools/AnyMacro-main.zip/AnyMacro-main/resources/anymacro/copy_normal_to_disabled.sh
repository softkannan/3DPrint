#!/bin/bash

cp 16x16.png 16x16-disabled.png
cp 32x32.png 32x32-disabled.png
