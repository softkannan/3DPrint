# SuperSlicerConfig
These are my recent superslicer settings. K3 and V2 are up to date.
On windows, place the files in %APPDATA%/SuperSlicer
