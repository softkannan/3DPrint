Hello everyone!

Today I'm going to answer some questions I've recieved from the community about resonance testing and input_shaper! Don't be disappointed, as always, we'll get into some theory on why I believe we see these results :) 

### Review over week testing

-Review gates belt tension calculations

-Trying to get repeatibility on XY belts

-Troubleshooting 2mm artifacts (belts too tight)

-Replaced belt and pulleys

-Doing study of belt tension vs. ringing/print quality w/ w/o input_shaper



### Wrong frequency measurements

-Verify your slicer orients the ringing test print correctly



-Pressure Advance with [input_shaper]





-Lower frequency has more damping but higher amplitude



-Damping ratio may not be directly comparable to config setting