#!/bin/bash
printf "Trigorilla Firmware Config\n"
printf "Select Microcontroller Architecture Atmega AVR / atmega2560 / 16Mhz\n"
printf "Select ***Enable Anycubic 4Max Pro Stock Display*** and on the menu then select ***UART3*** as serial port for Stock Display\n"
rm ~/klipper/.config
cd ~/klipper
make menuconfig
FILE=~/klipper/.config
if test -f "$FILE"; then
    printf "Copying ~/klipper/.config to ~/klipper_config/boards/trigorilla/firmware.config\n"
    cp -f ~/klipper/.config ~/klipper_config/boards/trigorilla/firmware.config
fi
printf "Host CPU Rpi Firmware Config\n"
printf "Select Microcontroller Architecture Linux Process\n"
rm ~/klipper/.config
cd ~/klipper
make menuconfig
FILE=~/klipper/.config
if test -f "$FILE"; then
    printf "Copying ~/klipper/.config to ~/klipper_config/boards/rpi/firmware.config\n"
    cp -f ~/klipper/.config ~/klipper_config/boards/rpi/firmware.config
fi
