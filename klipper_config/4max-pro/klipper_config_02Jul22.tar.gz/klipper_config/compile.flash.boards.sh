#!/bin/bash
# Trigorilla
printf "******************************************\n"
printf "***Starting Trigorilla Firmware Compile***\n"
printf "******************************************\n"
printf "Copying ~/klipper_config/boards/trigorilla/firmware.config to ~/klipper/.config\n"
cp -f ~/klipper_config/boards/trigorilla/firmware.config ~/klipper/.config
cd ~/klipper
printf "Start compiling Trigorilla firmware\n"
#make olddefconfig
make clean
make
printf "Stoping klipper service\n"
sudo service klipper stop
printf "Start FLASHING the trigorilla firmware"
make flash FLASH_DEVICE=/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0
printf "Starting klipper service\n"
sudo service klipper start
# RPi
printf "*****************************************\n"
printf "***Starting Host CPU Firmware Compile****\n"
printf "*****************************************\n"
printf "Copying ~/klipper_config/boards/rpi/firmware.config to ~/klipper/.config\n"
cp -f ~/klipper_config/boards/rpi/firmware.config ~/klipper/.config
cd ~/klipper
#make olddefconfig
make clean
make
printf "Stoping klipper service\n"
sudo service klipper stop
printf "Start FLASHING the hostcpu (just copying linux binary) firmware"
make flash
printf "Starting klipper service\n"
sudo service klipper start