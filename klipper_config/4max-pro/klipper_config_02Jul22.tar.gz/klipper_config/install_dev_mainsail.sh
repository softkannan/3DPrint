#!/bin/bash

top_border(){
  echo -e "/=======================================================\\"
}

bottom_border(){
  echo -e "\=======================================================/"
}

blank_line(){
  echo -e "|                                                       |"
}

hr(){
  echo -e "|-------------------------------------------------------|"
}

quit_footer(){
  hr
  echo -e "|                        ${red}Q) Quit${default}                        |"
  bottom_border
}

back_footer(){
  hr
  echo -e "|                       ${green}B) « Back${default}                       |"
  bottom_border
}

back_help_footer(){
  hr
  echo -e "|         ${green}B) « Back${default}         |        ${yellow}H) Help [?]${default}        |"
  bottom_border
}
### set some messages
warn_msg(){
  echo -e "${red}<!!!!> $1${default}"
}
status_msg(){
  echo; echo -e "${yellow}###### $1${default}"
}
ok_msg(){
  echo -e "${green}>>>>>> $1${default}"
}
title_msg(){
  echo -e "${cyan}$1${default}"
}
get_date(){
  current_date=$(date +"%y%m%d-%H%M")
}
print_unkown_cmd(){
  ERROR_MSG="Invalid command!"
}

print_msg(){
  if [[ "$ERROR_MSG" != "" ]]; then
    echo -e "${red}"
    echo -e "#########################################################"
    echo -e " $ERROR_MSG "
    echo -e "#########################################################"
    echo -e "${default}"
  fi
  if [ "$CONFIRM_MSG" != "" ]; then
    echo -e "${green}"
    echo -e "#########################################################"
    echo -e " $CONFIRM_MSG "
    echo -e "#########################################################"
    echo -e "${default}"
  fi
}

clear_msg(){
  unset CONFIRM_MSG
  unset ERROR_MSG
}

install_webui(){

  [ $SELECTED_WEB_UI == "mainsail" ] && IF_NAME1="Mainsail" && IF_NAME2="Mainsail     "
  [ $SELECTED_WEB_UI == "fluidd" ] && IF_NAME1="Fluidd" && IF_NAME2="Fluidd       "

  ### install mainsail/fluidd
  [ $SELECTED_WEB_UI == "mainsail" ] && mainsail_setup
  [ $SELECTED_WEB_UI == "fluidd" ] && fluidd_setup

  ### confirm message
  CONFIRM_MSG="$IF_NAME1 has been set up!"
  print_msg && clear_msg
}

mainsail_setup(){
  ### get mainsail download url
  MAINSAIL_DL_URL=~/dev_kit/mainsail.zip
  
  status_msg "Instaling Mainsail $MAINSAIL_DIR ..."

  ### remove existing and create fresh mainsail folder, then download mainsail
  [ -d $MAINSAIL_DIR ] && rm -rf $MAINSAIL_DIR
  mkdir $MAINSAIL_DIR && cd $MAINSAIL_DIR
  status_msg "Downloading Mainsail $MAINSAIL_VERSION ..."
  cp $MAINSAIL_DL_URL $MAINSAIL_DIR && ok_msg "Download complete!"

  ### extract archive
  status_msg "Extracting archive ..."
  unzip -q -o *.zip && ok_msg "Done!"

  ### delete downloaded zip
  status_msg "Remove downloaded archive ..."
  rm -rf *.zip && ok_msg "Done!"

}

enable_mainsail_remotemode(){
  rm -f $MAINSAIL_DIR/config.json
  echo -e "{\n    \"remoteMode\":true\n}" >> $MAINSAIL_DIR/config.json
}

fluidd_setup(){
  ### get fluidd download url
  FLUIDD_DL_URL=$(curl -s https://api.github.com/repositories/295836951/releases/latest | grep browser_download_url | cut -d'"' -f4)

  ### remove existing and create fresh fluidd folder, then download fluidd
  [ -d $FLUIDD_DIR ] && rm -rf $FLUIDD_DIR
  mkdir $FLUIDD_DIR && cd $FLUIDD_DIR
  status_msg "Downloading Fluidd $FLUIDD_VERSION ..."
  wget $FLUIDD_DL_URL && ok_msg "Download complete!"

  ### extract archive
  status_msg "Extracting archive ..."
  unzip -q -o *.zip && ok_msg "Done!"

  ### delete downloaded zip
  status_msg "Remove downloaded archive ..."
  rm -rf *.zip && ok_msg "Done!"
}

SELECTED_WEB_UI=mainsail
MAINSAIL_DIR=~/mainsail
cd ~
install_webui
