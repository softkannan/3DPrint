sudo apt update --allow-releaseinfo-change && sudo apt upgrade
sudo apt install git dfu-util unzip