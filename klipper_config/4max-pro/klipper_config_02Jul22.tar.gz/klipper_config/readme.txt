Building Klipper firmware
-------------------------

cd ~/klipper/
make menuconfig
make

Find USB Serial device name
---------------------------

ls /dev/serial/by-id/*

Flash Klipper firmware
----------------------

sudo service klipper stop
make flash FLASH_DEVICE=/dev/serial/by-id/usb-Klipper_Klipper_firmware_12345-if00
sudo service klipper start


How do I upgrade to the latest software (Full Upgrade)?
-------------------------------------------------------

The general way to upgrade is to ssh into the Raspberry Pi and run:

cd ~/klipper
git pull
~/klipper/scripts/install-octopi.sh
Then one can recompile and flash the micro-controller code. For example:

Firmware Build:
  SKR Mini 1.1 DIP:
    make menuconfig
      Select following parameters
        Micro-controller Architecture: STMicroelectronics STM32
        Processor model: STM32F103
        Bootloader offset: 28KiB bootloader
      Then check(with spacebar) Enable extra low-level configuration options at the top and enter !PC13 to GPIO pins to set at micro-controller startup.
      Exit and keep following the guide. 
    make clean
    make
  
  AVR:
    make menuconfig
      For 4Max Pro make sure to enable "Enable Anycubic 4Max Pro Stock Display" on the menu and select "UART3" as serial port for Stock Display
    make clean
    make
    
  RPi as a secondary MCU:
  
    Enabling SPI:
       sudo raspi-config enable under "Interfacing options"
    
    Add Startup Hook for "klipper_mcu process" (this emulate RPI mcu) :
    
      cd ~/klipper/
      sudo cp "./scripts/klipper-mcu-start.sh" /etc/init.d/klipper_mcu
      sudo update-rc.d klipper_mcu defaults
    
    Build Rpi MCU emulation process:
      cd ~/klipper/
      make menuconfig
         "Microcontroller Architecture" to "Linux process," then save and exit.
      sudo service klipper stop
      make flash
      sudo service klipper start 
    Add your user to the tty group:
      sudo usermod -a -G tty pi

Find USB Connection:
  ls /dev/serial/by-id/*

Firmware Flash:
  SKR Mini 1.1 DIP:
  
    First Time Flashing Klippers: 
    
      copy "~/klipper/out/kipper.bin" file to sdcard.
      Rename klipper.bin to firmware.bin. When this file is present printer flashes itself with that firmware.
        sudo service klipper stop
      put the sd-card back into machine and power cycle the machine
      find the connected usb name using "ls /dev/serial/by-id/*" and make sure the same name is specified on the printer.cfg ([mcu]) tag. if not update the printer.cfg
        sudo service klipper start
        
    Typical Upgrade Procedure:
    
      The procedure for updating MCU firmware using the SD Card is similar to that of other methods. 
      Instead of using make flash it is necessary to run a helper script, flash-sdcard.sh. 
      Updating a BigTreeTech SKR DIP 1.1 might look like the following:
      
      Leave the SDCARD in slot, it is needed for this procedure to work. (FAT32 Formated card is required)
        sudo service klipper stop
        cd ~/klipper
        git pull
        make clean
        make menuconfig
        make
        ./scripts/flash-sdcard.sh /dev/ttyACM0 btt-skr-e3-dip
        sudo service klipper start
      It is up to the user to determine the device location and board name. 
      If a user needs to flash multiple boards, flash-sdcard.sh (or make flash if appropriate) should be run for each board prior to restarting the Klipper service.
      Supported boards can be listed with the following command:
      
        ./scripts/flash-sdcard.sh -l
  AVR:
    sudo service klipper stop
    find the connected usb name using "ls /dev/serial/by-id/*" and use the name on bellow command
    make flash FLASH_DEVICE=/dev/serial/by-id/usb-Klipper_Klipper_firmware_12345-if00
    make flash FLASH_DEVICE=/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0
    find the connected usb name using "ls /dev/serial/by-id/*" and make sure the same name is specified on the printer.cfg ([mcu]) tag. if not update the printer.cfg
    sudo service klipper start

Flash Arduino Pro Micro

In order to upload to the Arduino's microcontroller via the USB cable a program called a bootloader that is stored in a special section of memory needs to be running. This program runs on startup and waits for a short time to see if an upload will start. On Arduino boards like Uno, Nano, Mega the microcontroller is automatically reset by the serial connection being opened at the start of the upload, which causes the bootloader to run. On the ATmega32U4 boards like Pro Micro it's not possible to do that automatic reset so what the Arduino IDE does is open a serial connection at 1200 baud. There is some code added to the Pro Micro's sketch that interprets that 1200 baud connection as a special signal to to reset the board so that the bootloader will run. When the bootloader is running the board will actually show up on a different COM port so the Arduino IDE then scans for the first new COM port to appear and then starts the upload to that COM port via AVRDUDE.

Since it would be difficult to do the standard Pro Micro reset sequence from the command line I had you instead do a manual reset by momentarily connecting the RST pin to ground, which causes the bootloader to run. Then you just need to start the AVRDUDE command before the bootloader times out and exits to whatever program you had previously uploaded to the Pro Micro. Luckily the bootloader tends to be assigned the same COM port every time so that's why you could reuse the upload command generated by the Arduino IDE.

cat /dev/ttyS0

make flash FLASH_DEVICE=/dev/serial/by-id/usb-Arduino_LLC_Arduino_Micro-if00

stty -F /dev/ttyACM1 speed 1200
avrdude -p m32U4 -P /dev/ttyACM1 -b 57600 -u -c avr109 -D -U flash:w:out/klipper.elf.hex

avrdude -Cavrdude.conf -V -patmega32u4 -cavr109 -P/dev/ttyUSB0 -b57600 -D -Uflash:w:out/klipper.elf.hex


However, it's often the case that only the host software changes. In this case, one can update and restart just the host software with:

cd ~/klipper
git pull
sudo service klipper restart

If after using this shortcut the software warns about needing to reflash the micro-controller or some other unusual error occurs, then follow the full upgrade steps outlined above. Note that the RESTART and FIRMWARE_RESTART g-code commands do not load new software - the above "sudo service klipper restart" and "make flash" commands are needed for a software change to take effect.

When upgrading the software, be sure to check the config changes document for information on software changes that may require updates to your printer.cfg file.

Octoprint Plugins
-----------------

Combined Temperature and Control Tab
https://github.com/foosel/OctoPrint-ConsolidateTempControl

TabOrder [icons => fas fa-thermometer-full fa-lg, fas fa-arrows-alt fa-lg, fas fa-layer-group fa-lg, fas fa-terminal fa-lg]
Cancel Objects
DryRun Plugin
Emergency Stop Button
Firmware Updater
M73-Progress-Plugin
OctoKlipper
PrintTimeGenius Plugin


#####################################################################
#   MCU Settings
#####################################################################
[mcu]
##  Obtain definition by "ls -l /dev/serial/by-id/" then unplug to verify
#To create easy naming for your printers you can create Udev rules and give the printer a normal name.
#First you have to find the USB ide of your printer connect it to your Pi and ensure uts turned on and give the following command in the Pi Terminal:
#lsusb and you would see some lines likeL
#Bus 002 Device 001: ID 1d6b:0003 Linux Foundation 3.0 root hub
#Bus 001 Device 019: ID 1d50:614e OpenMoko, Inc.
#Bus 001 Device 002: ID 2109:3431 VIA Labs, Inc. Hub
#Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub
#In this case the OpenMoko is the Octopus board and we are looking for the ID in this case 1d50:614e.
#Then use the following command on the terminal:  sudo nano /etc/udev/rules.d/99-usb-serial.rules
#This will open the nano editor and copy / type the following in that: SUBSYSTEMS=="usb", ATTRS{idProduct}=="AAAA",  ATTRS{idVendor}=="BBBB", ACTION=="add", SYMLINK+="NAME"
#Where AAAA is the first part of the ID and BBBB the second part and where name stand you can give your printer an easy name.
#In my case it became like: SUBSYSTEMS=="usb", ATTRS{idProduct}=="614e",  ATTRS{idVendor}=="1d50", ACTION=="add", SYMLINK+="btt-octopus-11"
#When this is done you can reach the printer now over a Symlink and this can be used as the Serial port see below
#
##--------------------------------------------------------------------
serial: /dev/btt-octopus-11
#/dev/serial/by-id/usb-Klipper_stm32f446xx_3D002A000950534E4E313020-if00
#restart_method: command
##--------------------------------------------------------------------
# JG MCU's 
# Octopus: serial: /dev/serial/by-id/usb-Klipper_stm32f446xx_3D002A000950534E4E313020-if00
# Einsy: serial: /dev/serial/by-id/usb-Prusa_Research__prusa3d.com__Original_Prusa_i3_MK3-if00
# Duet: serial: /dev/serial/by-id/usb-Klipper_samd51p20a_8090AF1E484633532020204E221118FF-if00
#		restart_method: command
##--------------------------------------------------------------------