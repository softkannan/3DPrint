#!/bin/bash
# Trigorilla
cp -f ~/klipper_config/boards/trigorilla/firmware.config ~/klipper/.config
cd ~/klipper
#make olddefconfig
make clean
make
cp ~/klipper/out/klipper.elf.hex ~/klipper_config/firmwares/firmware-trigorilla.hex