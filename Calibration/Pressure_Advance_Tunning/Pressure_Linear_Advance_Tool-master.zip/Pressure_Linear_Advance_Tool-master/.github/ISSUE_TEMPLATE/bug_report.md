---
name: Bug report
about: Bug report
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Klipper Error Message (if applicable)**

**G-code File**
Please drag your g-code file here.

**Screenshots**
If applicable, add screenshots to help explain your problem.
