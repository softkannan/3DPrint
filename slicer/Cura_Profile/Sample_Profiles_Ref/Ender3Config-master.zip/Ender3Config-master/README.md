# Ender3Config
Copy the files of 3.4 to your %appdata%/cura
