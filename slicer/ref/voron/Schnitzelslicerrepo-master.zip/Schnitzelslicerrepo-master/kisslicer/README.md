#Kisslicer by Stephan

using a postprocessiong to make lines moar fat and travels moar acceleration.
see tab in printer->firmware
