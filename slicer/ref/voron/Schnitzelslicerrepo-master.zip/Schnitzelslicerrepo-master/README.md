# Schnitzelslicerrepo²
This is a collection of slicerprofiles the humans made in #landofschnitzel on voron discord.
