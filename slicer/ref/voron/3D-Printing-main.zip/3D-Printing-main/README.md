random 3d printing stuff
