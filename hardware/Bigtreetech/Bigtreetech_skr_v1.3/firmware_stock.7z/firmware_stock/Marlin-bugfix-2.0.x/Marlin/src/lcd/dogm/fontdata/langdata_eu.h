/**
 * Generated automatically by buildroot/share/fonts/uxggenpages.sh
 * Contents will be REPLACED by future processing!
 * Use genallfont.sh to generate font data for updated languages.
 */
#include <U8glib.h>

#define FONTDATA_ITEM(page, begin, end, data) { page, begin, end, COUNT(data), data }
static const uxg_fontinfo_t g_fontinfo[] PROGMEM = {};
