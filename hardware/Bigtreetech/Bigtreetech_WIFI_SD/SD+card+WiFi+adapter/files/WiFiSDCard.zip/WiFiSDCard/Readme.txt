These documents and arduino sketches are provided by user @skrutch.
