# BTT-SD-TF-Cloud-V1.0
BTT SD/TF Cloud V1.0 is launched by the 3D printing team of ShenZhen BigTree Technology CO.,LTD ., which is a module for wireless file transmission between the master computer and the 3D printer, so that you can get rid of the constraint of plugging SD card.
