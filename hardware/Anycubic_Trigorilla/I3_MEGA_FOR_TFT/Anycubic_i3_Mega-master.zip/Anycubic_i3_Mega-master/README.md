# Anycubic_i3_Mega
Firmware and Resources for the Anycubic i3 Mega
