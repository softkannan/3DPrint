# I3-MEGA

ANYCUBIC I3 MEGA source code V1.1.1, based on marlin RC8 1.1.0.
