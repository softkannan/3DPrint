# TMC2130-V2.0
# License:
this project is a Stepper Motor Driver Board for 2-Phase Motors based on SilentStepStick https://github.com/watterott/SilentStepStick and Trinamic Motor Drivers.

Open-Source and released under the Creative Commons Attribution Share-Alike License.
