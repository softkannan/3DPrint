
[BIGTREETECH TMC2130 V3.0 Youtube Video](https://www.youtube.com/watch?v=k3Uc1F5jgVQ&t=35s)
