# TMC2209-V1.1
TMC2209 is an ultra-silent motor driver IC for two-phase stepper motors. Its continuous drive current is 2A and peak current is 2.8A. Compared with TMC2208, the driving current of this IC is not only improved by 0.6a-0.8a, but also this IC increases the function of locked-motor test.
