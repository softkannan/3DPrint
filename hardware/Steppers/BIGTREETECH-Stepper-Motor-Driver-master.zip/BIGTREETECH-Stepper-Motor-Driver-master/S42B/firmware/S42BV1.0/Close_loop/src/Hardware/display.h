#ifndef __DISPLAY_H
#define __DISPLAY_H


#include "main.h"


void Oled_display(void);

void Motor_data_dis(void);














#endif

