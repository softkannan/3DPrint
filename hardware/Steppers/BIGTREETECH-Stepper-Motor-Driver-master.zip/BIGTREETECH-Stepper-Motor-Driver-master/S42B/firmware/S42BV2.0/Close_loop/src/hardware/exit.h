#ifndef __EXIT_H
#define __EXIT_H	

#include "mydef.h"
	  
#define DIRIN     PAin(1)	
#define ENIN        PAin(2)
	 
void EXTIX_Init(void);//
		 					    
#endif

