#ifndef __DISPLAY_H
#define __DISPLAY_H


#include "mydef.h"


void Oled_display(void);

void Motor_data_dis(void);














#endif

