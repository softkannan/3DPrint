# BIGTREETECH-TMC2208-V2.1
TMC2208 single-axis stepper motor drive chip, power tube built-in drive current 1.4A peak current 2A, voltage range 4.75V-36V, 256 subdivision;MicroPlyer: 1/2, 1/4, 1/8, 1/16, 1/32
# License:
this project is a Stepper Motor Driver Board for 2-Phase Motors based on SilentStepStick https://github.com/watterott/SilentStepStick and Trinamic Motor Drivers.

Open-Source and released under the Creative Commons Attribution Share-Alike License.
