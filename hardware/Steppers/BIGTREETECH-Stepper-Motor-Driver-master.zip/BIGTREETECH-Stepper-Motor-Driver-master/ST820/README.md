# BIGTREETECH-ST820-V1.0
 Supply voltage from 7 V to 45 V.Output current up to 1.5 A rms for each motor phase.Stepper motor driving with a microstepping resolution up to 1/256th of step
